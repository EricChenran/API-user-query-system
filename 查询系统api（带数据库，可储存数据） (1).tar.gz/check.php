<?php
$conn=mysqli_connect('localhost','数据库账号','数据库密码','数据库名称'); //连接数据库
$name=$_GET['name'];
$result=mysqli_query($conn,"SELECT * FROM `info` WHERE name='$name'");
if($result){
    $rows=mysqli_fetch_array($result);
    $info=array('姓名'=>$rows['name'],'年龄'=>$rows['age'],'QQ'=>$rows['qq']);
    echo json_encode($info);
}else{
    echo "null";
}
?>